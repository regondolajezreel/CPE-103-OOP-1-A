stuff = 'Hello\nWorld!'
stuff
print(stuff)
stuff = 'X\nY'
print(stuff)
len(stuff)