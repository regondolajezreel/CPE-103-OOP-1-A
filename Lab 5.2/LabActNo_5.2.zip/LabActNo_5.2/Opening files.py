fhand = open('mbox.txt')
print(fhand)
fhand = open('stuff.txt')